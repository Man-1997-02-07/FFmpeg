MediaInfo - http://MediaArea.net/MediaInfo
Copyright (c) MediaArea.net SARL, Info@MediaArea.net

License
-------
This program is freeware (BSD-style license).
See License.html for more information.


Usage
-----
mediainfo FileName
mediainfo --Help
