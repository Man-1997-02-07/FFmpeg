#/bin/bash

perl _update_file_in_stringsdb.pl ../English.lproj/About.strings
perl _update_file_in_stringsdb.pl ../English.lproj/MainMenu.strings
perl _update_file_in_stringsdb.pl ../English.lproj/MyWindow.strings
perl _update_file_in_stringsdb.pl ../English.lproj/Preferences.strings
perl _update_file_in_stringsdb.pl ../English.lproj/Localizable.strings
perl _update_file_in_stringsdb.pl ../English.lproj/ServicesMenu.strings
